
document.getElementById("tabla").addEventListener("submit", function () {

     var numero= document.getElementById("numero").value
      for(var i=0; i<=12; i++){
        var rest= numero*i;
        document.write(numero+"*"+i+"= "+rest+ '<br>')
        
      }
    })
  
